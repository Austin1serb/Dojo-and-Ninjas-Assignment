package com.austin.dojosandninjas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojosandninjasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojosandninjasApplication.class, args);
	}

}
