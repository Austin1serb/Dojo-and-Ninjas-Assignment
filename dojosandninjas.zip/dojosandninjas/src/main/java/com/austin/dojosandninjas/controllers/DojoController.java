package com.austin.dojosandninjas.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.austin.dojosandninjas.models.Dojo;
import com.austin.dojosandninjas.services.DojoService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/dojos")
public class DojoController {

    @Autowired
    private DojoService dojoService;

    // Render the form for a new dojo
    @GetMapping("/new")
    public String newDojo(Model model) {
        model.addAttribute("dojo", new Dojo());
        return "newDojo.jsp"; // Assuming this JSP displays the form for a new dojo
    }

    // Handle the form submission for a new dojo
    @PostMapping
    public String createDojo(@Valid @ModelAttribute("dojo") Dojo dojo) {
        dojoService.save(dojo);
        return "redirect:/dojos";
    }

    // Display all ninjas for a specific dojo
    @GetMapping("/{dojo_id}")
    public String showDojo(@PathVariable Long dojo_id, Model model) {
        Dojo dojo = dojoService.findById(dojo_id);
        model.addAttribute("dojo", dojo);
        return "showDojo.jsp"; // Assuming this JSP displays ninjas for a dojo
    }
}
