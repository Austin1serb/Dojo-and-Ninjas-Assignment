package com.austin.dojosandninjas.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.austin.dojosandninjas.models.Ninja;
import com.austin.dojosandninjas.services.DojoService;
import com.austin.dojosandninjas.services.NinjaService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/ninjas")
public class NinjaController {

    @Autowired
    private NinjaService ninjaService;

    @Autowired
    private DojoService dojoService;

    // Render the form for a new ninja
    @GetMapping("/new")
    public String newNinja(Model model) {
        model.addAttribute("ninja", new Ninja());
        model.addAttribute("dojos", dojoService.findAll());
        return "newNinja.jsp"; // Assuming this JSP displays the form for a new ninja
    }

    // Handle the form submission for a new ninja
    @PostMapping
    public String createNinja(@Valid @ModelAttribute("ninja") Ninja ninja) {
        ninjaService.create(ninja);
        return "redirect:/dojos";
    }
}
