package com.austin.dojosandninjas.models;

import java.util.Date;
import java.util.Objects;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "ninjas")
public class Ninja {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String firstName;
    private String lastName;
    private int age;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dojo_id")
    private Dojo dojo;
    @Column(updatable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date createdAt;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date updatedAt;

    public Ninja() {
    }

    public Ninja(Long id, String firstName, String lastName, int age, Dojo dojo) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.dojo = dojo;
    }

    @PrePersist
    protected void onCreate() {
        this.createdAt = new Date();
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = new Date();
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return this.age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Dojo getDojo() {
        return this.dojo;
    }

    public void setDojo(Dojo dojo) {
        this.dojo = dojo;
    }

    public Ninja id(Long id) {
        setId(id);
        return this;
    }

    public Ninja firstName(String firstName) {
        setFirstName(firstName);
        return this;
    }

    public Ninja lastName(String lastName) {
        setLastName(lastName);
        return this;
    }

    public Ninja age(int age) {
        setAge(age);
        return this;
    }

    public Ninja dojo(Dojo dojo) {
        setDojo(dojo);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof Ninja)) {
            return false;
        }
        Ninja ninja = (Ninja) o;
        return Objects.equals(id, ninja.id) && Objects.equals(firstName, ninja.firstName) && Objects.equals(lastName, ninja.lastName) && age == ninja.age && Objects.equals(dojo, ninja.dojo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, firstName, lastName, age, dojo);
    }

    @Override
    public String toString() {
        return "{"
                + " id='" + getId() + "'"
                + ", firstName='" + getFirstName() + "'"
                + ", lastName='" + getLastName() + "'"
                + ", age='" + getAge() + "'"
                + ", dojo='" + getDojo() + "'"
                + "}";
    }

}
