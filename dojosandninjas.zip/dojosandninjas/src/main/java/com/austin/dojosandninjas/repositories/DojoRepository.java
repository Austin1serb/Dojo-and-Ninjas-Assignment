package com.austin.dojosandninjas.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import com.austin.dojosandninjas.models.Dojo;

@Component
public interface DojoRepository extends CrudRepository<Dojo, Long> {

    List<Dojo> findAll();
}
