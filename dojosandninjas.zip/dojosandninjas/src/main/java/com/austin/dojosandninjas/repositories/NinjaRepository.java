package com.austin.dojosandninjas.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import com.austin.dojosandninjas.models.Ninja;

@Component
public interface NinjaRepository extends CrudRepository<Ninja, Long> {

    List<Ninja> findAll();
}
