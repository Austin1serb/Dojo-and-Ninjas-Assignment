package com.austin.dojosandninjas.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.austin.dojosandninjas.models.Dojo;
import com.austin.dojosandninjas.repositories.DojoRepository;

@Service
public class DojoService {

    @Autowired
    private DojoRepository dojoRepo;

    public Dojo findById(Long id) {
        return dojoRepo.findById(id).orElse(null);
    }

    public List<Dojo> findAll() {
        return dojoRepo.findAll();
    }

    public Dojo save(Dojo dojo) {
        return dojoRepo.save(dojo);
    }
}
